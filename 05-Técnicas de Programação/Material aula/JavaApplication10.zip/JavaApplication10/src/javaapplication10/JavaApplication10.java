/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication10;

import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author Rodrigo
 */
public class JavaApplication10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc;
        
        sc = StaticClass.receberTeclado();
        
        double valor1, valor2;
        
        System.out.println("Digite um valor: ");
        valor1 = sc.nextDouble();
        System.out.println("Digite outro valor: ");
        valor2 = sc.nextDouble();
        
        StaticClass.soma(valor1, valor2);
        StaticClass.potencia(valor1, valor2);
        StaticClass.divisao(valor1, valor2);
        
        
        
        
        
        
        
    }
    
}
