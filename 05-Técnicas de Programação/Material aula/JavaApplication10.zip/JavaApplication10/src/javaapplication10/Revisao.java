/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication10;

/**
 *
 * @author Rodrigo
 */
public class Revisao {
    
    private int x;
    private double d;
    private String s;
    
    // IF - condicionais
    public void metodoIF(){
        if(x < 0){
            System.out.println("Numero negativo");
        }    
    }
    
    public void metodoIfElse(){
       if(x < 0){
           System.out.println("Numero negativo!!!");
       }else{
           System.out.println("Numero positivo!!!");
       }
    }
    
    public void metodoIfElseIf(){
       if(x > 0 && x <= 10){
           System.out.println("X entre 0 e 10");
       
       }else if(x > 10 && x <= 20){
           System.out.println("X entre 11 e 20");
       }else{
           System.out.println("X maior que 20 ou menor que 0");  
       }
    }
    
    public void metodoSwitch(){
        int opcao = 0;
        
        switch(opcao){
            
            case 1: 
                System.out.println("Caso 1");
                break;
                
            case 2:
                System.out.println("Caso 2");
                break;
            
            default:
                System.out.println("Fora das opcoes");
        }   
    }
    
    public void metodoWhile(){
      while(x < 10){
          System.out.println("X: "+x);
          x++;
         // x++;
         // x = x + 1;
         // x +=1;
      }
    }
    
    public void metodoFor(){
       for(int i = 0; i < 10; i++){
           System.out.println("de 1 em 1");
       }     
       
       for(int j = 0; j < 10;   ){
           System.out.println("De 2 em 2");
           j = j + 2;
       }
       
       for(;;){
           System.out.println("Looping infinito!!!");
       }       
    }
    
    
    
}
