/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aulaheranca;

/**
 *
 * @author lab04
 */
public class AulaHeranca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // instanciar o Carro
        
        Carro c = new Carro(1, 4, "Azul", 4, 2);
        
        // System.out.println("Airbag: "+c.getAirbag());
        // System.out.println("Portas: "+c.getPortas());
        
        c.imprimir();
        
        c.setRodas(5);
        System.out.println("============================");
        c.imprimir();
        
        
        
        
    }
    
}
