/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aulaheranca;

/**
 *
 * @author lab04
 */
public class Carro extends Veiculo {
    
    // atributos
    private int portas;
    private int airbag;
    
    public Carro(int motor, int rodas, 
            String cor, int portas, int airbag){
            
            // acessa o construtor da SUPERCLASSE (Veiculo) 
            super(motor, rodas, cor);  
            this.portas = portas;
            this.airbag = airbag;
    }
    
    public void setPortas(int portas){
      this.portas = portas;
    }
    
    public void setAirbag(int airbag){
       this. airbag = airbag;
    }
    
    public int getPortas(){
      return portas;
    }
    
    public int getAirbag(){
      return airbag;
    }
    
    @Override
    public void imprimir(){
        super.imprimir(); // imprimir todos os atributos de veículo
        System.out.println("Portas: "+portas);
        System.out.println("Airbag:"+airbag);
    }
    
    @Override
    public void setRodas(int rodas){
      super.setRodas(rodas);
    }
    
   
  
    
    
    
}
