/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package exercicio_4;

/**
 *
 * @author danie
 */
public interface InterfaceVeiculos {
    
    public void mover();
    public void abastecer();
    
}
