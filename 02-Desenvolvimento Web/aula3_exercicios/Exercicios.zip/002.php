<?php
/*
Escreva um script que imprima qual o maior número.
Use IF
*/
$a = 16;
$b = 11;

    if($a>$b){
        echo 'O maior numero é: ' . $a . '<br>';
    } else{
        echo 'O maior numero é: ' . $b . '<br>';
    }



?>