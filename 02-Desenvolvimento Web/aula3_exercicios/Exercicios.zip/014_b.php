<?php
/*
Importar a função criada em 014_a.php para ser utilizada aqui.
*/
include '014_a.php';

$nota_1 = 9;
$nota_2 = 4;
calculo_media($nota_1, $nota_2);
// Calcular chamando a função

$nota_1 = 1;
$nota_2 = 5;
calculo_media($nota_1, $nota_2);
// Calcular chamando a função

$nota_1 = 5;
$nota_2 = 3;
calculo_media($nota_1, $nota_2);
// Calcular chamando a função
?>