<?php

# Acesse /superglobais.php
print(var_dump($_SERVER ));

# Acesse /superglobais.php?faculdade=Fatec&cidade=Araras
# print(var_dump($_GET ));
# print(var_dump($_POST ));
# print(var_dump($FILES ));
# print(var_dump($_COOKIE ));
# print(var_dump($_REQUEST ));
# print(var_dump($_ENV ));
# print(var_dump($GLOBALS ));
?>