<?php

function quadrado($numero){
    return $numero * $numero;
}

?>