<html>
   
   <head>
      <title>Cookies com PHP</title>
   </head>
   
   <body>
      Funções para manipular cookies
      <br/>
      <?php
         echo $_COOKIE["nome"]. "<br />";
         print_r($_COOKIE);
      ?>
   </body>
   
</html>
