<html>
   
   <head>
      <title>Session com PHP</title>
   </head>
   
   <body>
      Mostrar a superglobal Session
      <br/>
      <?php
         # session_start();
         print_r($_SESSION);
      ?>
   </body>
   
</html>
