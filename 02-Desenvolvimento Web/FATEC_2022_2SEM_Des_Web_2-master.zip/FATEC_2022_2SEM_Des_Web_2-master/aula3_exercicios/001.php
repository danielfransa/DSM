<?php
/*
Variáveis 
*/

$variavel_1 = 'texto';
// Imprimir o valor a variável e o seu tipo

$variavel_2 = 123;
// Imprimir o valor a variável e o seu tipo

$variavel_3 = 1;
// Imprimir o valor a variável e o seu tipo

$array = [
    "foo" => "bar",
    "bar" => "foo",
];
// Imprimir o valor a variável e o seu tipo

?>