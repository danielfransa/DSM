package exercicio1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author danie
 */
public class Calculadora {
    
    public static double soma(double x, double y){
        return x + y;
    }
    
    public static double subtracao(double x, double y, double z){
        return (x - y) + z;
    }
     
    public static double multiplicacao(double x, double y){
        return x * y;
    }
    
    public static double divisão(double x, double y){
        return x/y;
    }
}
