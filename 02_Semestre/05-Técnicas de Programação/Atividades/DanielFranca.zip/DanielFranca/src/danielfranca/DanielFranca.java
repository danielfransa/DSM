/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package danielfranca;

import java.util.InputMismatchException;
import java.util.MissingFormatArgumentException;
import java.util.Scanner;

/**
 *
 * @author f290ti
 */
public class DanielFranca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
    Funcionarios f = new Funcionarios();
     
    Scanner sc = new Scanner(System.in);
     
    
    System.out.println("Digite o nome:");
    f.setName(sc.next());
    
    int a;
    try{
    System.out.println("Digite a idade:");
    a = sc.nextInt() ;
    }catch(InputMismatchException e){
        System.out.println(" ");
        System.out.println("-----------");
        System.out.println("ATENÇÃO!!!!");
        System.out.println("-----------");
        System.out.println("Input incorreto digite números");
        System.out.println("Digite a idade:");
        sc = null;
        sc = new Scanner(System.in);
        a = sc.nextInt();
    }
    f.setIdade(a);
    
    System.out.println("Digite o cargo:");
    f.setCargo(sc.next());
    
    double b;
    try{
    System.out.println("Digite o salário:");
    b = sc.nextDouble();
    }catch(InputMismatchException e){
        System.out.println(" ");
        System.out.println("-----------");
        System.out.println("ATENÇÃO!!!!");
        System.out.println("-----------");
        System.out.println("Input incorreto digite números");
        System.out.println("Digite o salário:");
        sc = null;
        sc = new Scanner(System.in);
        b = sc.nextDouble();
    }
    f.setSalario(b);
    
    sc = null;
    sc = new Scanner(System.in);
    
    try{
    System.out.println("Digite a Matrícula:");
    a = sc.nextInt() ;
    }catch(InputMismatchException e){
        System.out.println(" ");
        System.out.println("-----------");
        System.out.println("ATENÇÃO!!!!");
        System.out.println("-----------");
        System.out.println("Input incorreto digite números");
        System.out.println("Digite a Matrícula:");
        sc = null;
        sc = new Scanner(System.in);
        a = sc.nextInt() ;
    }
    f.setMatricula(a);
    
    
    if("Diretor".equals(f.getCargo())){
        Diretor d = new Diretor();
        f.setSalario(d.calculoSalarioDiretor(f.getSalario()));
    }
    
    if("Gerente".equals(f.getCargo())){
        Gerente g = new Gerente();
        f.setSalario(g.calculoSalarioGerente(f.getSalario()));
    }
    
    
    
    System.out.println("----------------------------------");    
    System.out.println("Nome:"+f.getName());
    System.out.println("Idade:"+f.getIdade());
    System.out.println("Função:"+f.getCargo());
    System.out.println("Salário:"+f.getSalario());
    System.out.println("Matricula:"+f.getMatricula());
        
    }
      
}
