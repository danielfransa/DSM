/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package danielfranca;

/**
 *
 * @author f290ti
 */
public class Gerente extends Funcionarios{
    
    public double calculoSalarioGerente(double salario){
        return salario * 1.40;
        
    };
    
}
