/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package danielfranca;

/**
 *
 * @author f290ti
 */
public interface Pessoa {
    

    public String getName();
    public void setName(String name);

    public int getIdade();
    public void setIdade(int idade);
    
}
