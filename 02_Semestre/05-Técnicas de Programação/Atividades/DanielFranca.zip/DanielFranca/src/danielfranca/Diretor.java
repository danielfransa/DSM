/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package danielfranca;

/**
 *
 * @author f290ti
 */
public class Diretor extends Funcionarios {

    public double calculoSalarioDiretor(double salario){
        return salario * 1.20;
        
    };

    
    
    
    
}
