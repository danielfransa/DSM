/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aulapolimorfismo;

/**
 *
 * @author lab04
 */
public abstract class NovaClasseAbstrata extends MinhaClasseAbstrata{
    @Override
    public abstract void texto();
    
}
